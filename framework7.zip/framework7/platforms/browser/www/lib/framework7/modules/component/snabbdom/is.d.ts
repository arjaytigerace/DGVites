export declare const array: (arg: any) => arg is any[];
export declare function primitive(s: any): s is (string | number);
